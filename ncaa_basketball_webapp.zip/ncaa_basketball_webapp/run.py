#!/usr/bin/env python

from flask_ncaa_mbb import application

application.run(debug=True)
